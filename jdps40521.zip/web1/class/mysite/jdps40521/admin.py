from django.contrib import admin
from .models import Hello

# Register your models here.

class HelloAdmin(admin.ModelAdmin):
	list_display = ('user', 'number', 'address')

admin.site.register(Hello)
