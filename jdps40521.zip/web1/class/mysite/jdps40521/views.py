from django.shortcuts import render_to_response
# Create your views here.
from .models import Hello

def index(request):
	hellos = Hello.objects.all()
	return render_to_response('jdps40521/menu.html',locals())